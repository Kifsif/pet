package com.example.security.service;

import com.example.security.entity.User;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class InMemoryUserService {
    private List<User> users = new ArrayList<>();

    public Optional<User> getByToken(String token) {
        return users.stream().filter(u -> u.getToken().equals(token)).findFirst();
    }

    @PostConstruct
    private void populate() {
        users.add(new User("Ruslan", 30));
        users.add(new User("John", 30));
        System.out.printf("Users have been added: %s", users);
    }
}
