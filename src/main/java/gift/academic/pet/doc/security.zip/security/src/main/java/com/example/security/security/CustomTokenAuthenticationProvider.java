package com.example.security.security;

import com.example.security.service.InMemoryUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

@Component
public class CustomTokenAuthenticationProvider implements AuthenticationProvider {
    @Autowired
    private InMemoryUserService userService;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        var token = ((CustomTokenAuthentication) authentication).getToken();
        var user = userService.getByToken(token).orElseThrow(() -> new BadCredentialsException("Invalid token"));
        return new CustomTokenAuthentication(user, true);
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.isAssignableFrom(CustomTokenAuthentication.class);
    }
}
