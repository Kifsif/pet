package com.example.security.config;

import com.example.security.security.CustomAuthenticationEntryPoint;
import com.example.security.security.CustomTokenAuthenticationFilter;
import com.example.security.security.CustomTokenAuthenticationProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

@Configuration
@EnableWebSecurity(debug = true)
public class SecurityConfig {

    @Autowired
    @Lazy
    private CustomAuthenticationEntryPoint authenticationEntryPoint;
    @Autowired
    @Lazy
    private CustomTokenAuthenticationFilter tokenAuthenticationFilter;

    @Autowired
    private CustomTokenAuthenticationProvider tokenAuthenticationProvider;

    @Bean
    public SecurityFilterChain configure(HttpSecurity http) throws Exception {
        http.csrf(AbstractHttpConfigurer::disable);

        http.httpBasic(Customizer.withDefaults());

        http.authorizeHttpRequests(c -> c.requestMatchers("/error").permitAll().anyRequest().authenticated());

        http.sessionManagement(c -> c.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

        http.addFilterBefore(tokenAuthenticationFilter, BasicAuthenticationFilter.class);

        http.exceptionHandling(c -> c.authenticationEntryPoint(authenticationEntryPoint));

        http.authenticationProvider(tokenAuthenticationProvider);

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }
}
