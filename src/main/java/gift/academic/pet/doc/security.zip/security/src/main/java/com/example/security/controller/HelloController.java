package com.example.security.controller;

import com.example.security.dto.Pet;
import com.example.security.entity.User;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/api")
@RestController
public class HelloController {

    @GetMapping("/hello")
    public String hello(@AuthenticationPrincipal User user) {
        User contextUser  = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return "hello";
    }

    @PostMapping("/pets")
    public String create(@ModelAttribute Pet pet) {
        return "hello";

    }
}
